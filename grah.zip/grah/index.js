const { Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMembers
    ]
});

const PREFIX = '!';
const DB_FILE = './rooms_db.json';

// الأيدي الخاص بك لتجاوز الصلاحيات
const BOT_OWNER_ID = '1262515901983494294'; 

// قاعدة بيانات الرومات
let serverRooms = {};
if (fs.existsSync(DB_FILE)) {
    serverRooms = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
}

// حفظ الجلسات لكل سيرفر
const sessions = {};

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

client.once('ready', () => {
    console.log(`تم تسجيل الدخول بنجاح باسم: ${client.user.tag}`);
});

client.on('messageCreate', async message => {
    if (message.author.bot || !message.guild || !message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // 1. أمر تحديد الرومات
    if (command === 'روم') {
        const isOwner = message.author.id === BOT_OWNER_ID;
        const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

        if (!isAdmin && !isOwner) {
            return message.reply("عذراً، يجب أن تمتلك صلاحية `Administrator`");
        }
        
        if (args.length < 2) {
            return message.reply("حط الرومات اول (!روم ايدي_الأحمر ايدي_الأزرق)");
        }
        
        serverRooms[message.guild.id] = { team1: args[0], team2: args[1] };
        fs.writeFileSync(DB_FILE, JSON.stringify(serverRooms, null, 2));
        return message.reply(`✅ تم حفظ الرومات!`);
    }

    // 2. أمر فتح القرعة بالخيارات الثلاثة
    if (command === 'قرعه' || command === 'gr3h') {
        sessions[message.guild.id] = { 
            randoms: [], 
            reds: [], 
            blues: [], 
            team1: [], 
            team2: [], 
            mainRoomId: null 
        };

        const randomBtn = new ButtonBuilder()
            .setCustomId('join_random')
            .setLabel('عشوائي 🎲')
            .setStyle(ButtonStyle.Secondary);

        const redBtn = new ButtonBuilder()
            .setCustomId('join_red')
            .setLabel('الفريق الأحمر 🔴')
            .setStyle(ButtonStyle.Danger);

        const blueBtn = new ButtonBuilder()
            .setCustomId('join_blue')
            .setLabel('الفريق الأزرق 🔵')
            .setStyle(ButtonStyle.Primary);

        const row = new ActionRowBuilder().addComponents(randomBtn, redBtn, blueBtn);

        await message.channel.send({
            content: '🎲 **تبي تشارك بالقرعه ؟**\nاضغط على زر:\n*(العدد الحالي: 0)*',
            components: [row]
        });
    }

    // 3. أمر التوزيع
    if (command === 'وزعنا') {
        const session = sessions[message.guild.id];
        const rooms = serverRooms[message.guild.id];

        if (!rooms || !rooms.team1 || !rooms.team2) {
            return message.reply("حط الرومات اول (!روم ايدي_الأحمر ايدي_الأزرق)");
        }

        if (!session) return message.reply("مافيه قرعه مفتوحه الحين!");
        
        const totalParticipants = session.randoms.length + session.reds.length + session.blues.length;
        if (totalParticipants < 2) {
            return message.reply("مافيه عدد ياوحيد");
        }

        const voiceChannel = message.member?.voice.channel;
        if (!voiceChannel) {
            return message.reply("لازم تكون بالروم عشان احفظه واقدر ارجعكم له!");
        }

        session.mainRoomId = voiceChannel.id;

        // تجهيز الفرق بناءً على اختيارات اللاعبين
        let team1 = [...session.reds];
        let team2 = [...session.blues];
        let randomPlayers = [...session.randoms];

        // خلط اللاعبين العشوائيين وتوزيعهم لتعديل الكفة
        shuffleArray(randomPlayers);
        randomPlayers.forEach((player) => {
            if (team1.length <= team2.length) {
                team1.push(player);
            } else {
                team2.push(player);
            }
        });

        session.team1 = team1;
        session.team2 = team2;

        const team1Mentions = session.team1.map(m => m.toString()).join('\n') || "لا يوجد";
        const team2Mentions = session.team2.map(m => m.toString()).join('\n') || "لا يوجد";

        const embed = new EmbedBuilder()
            .setTitle('🎲 نتائج القرعه 🎲')
            .setColor(0x0099FF)
            .addFields(
                { name: '🔴 الفريق الأحمر (Team 1)', value: team1Mentions, inline: true },
                { name: '🔵 الفريق الأزرق (Team 2)', value: team2Mentions, inline: true }
            )
            .setFooter({ text: 'استخدم الأزرار تحت للنقل للرومات' });

        const moveBtn = new ButtonBuilder()
            .setCustomId('move_teams')
            .setLabel('نقل للرومات')
            .setStyle(ButtonStyle.Success)
            .setEmoji('✈️');

        const returnBtn = new ButtonBuilder()
            .setCustomId('return_teams')
            .setLabel('إرجاع للروم الأساسي')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('🔙');

        const row = new ActionRowBuilder().addComponents(moveBtn, returnBtn);

        await message.channel.send({ embeds: [embed], components: [row] });
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    const guildId = interaction.guild.id;
    const session = sessions[guildId];
    const rooms = serverRooms[guildId];

    // التعامل مع أزرار المشاركة
    if (['join_random', 'join_red', 'join_blue'].includes(interaction.customId)) {
        if (!session) return interaction.reply({ content: 'مافيه قرعه الحين', ephemeral: true });

        // شرط التواجد في روم صوتي
        if (!interaction.member.voice.channel) {
            return interaction.reply({ content: '❌ لازم تكون موجود في روم عشان تقدر تشارك!', ephemeral: true });
        }

        // التحقق من عدم التسجيل المسبق
        const isRegistered = session.randoms.find(m => m.id === interaction.user.id) || 
                             session.reds.find(m => m.id === interaction.user.id) || 
                             session.blues.find(m => m.id === interaction.user.id);

        if (isRegistered) {
            return interaction.reply({ content: 'خاش يا اثول', ephemeral: true });
        }

        // تسجيل اللاعب حسب اختياره
        if (interaction.customId === 'join_random') session.randoms.push(interaction.member);
        else if (interaction.customId === 'join_red') session.reds.push(interaction.member);
        else if (interaction.customId === 'join_blue') session.blues.push(interaction.member);

        const total = session.randoms.length + session.reds.length + session.blues.length;
        await interaction.reply({ content: 'خشيت القرعه', ephemeral: true });

        // تحديث رسالة المشاركة بالعدد
        await interaction.message.edit({
            content: `🎲 **تبي تشارك بالقرعه ؟**\n اضغط على زر:\n*(العدد الحالي: **${total}**)*`
        });
    }

    // زر النقل للرومات
    if (interaction.customId === 'move_teams') {
        if (!session || (!session.team1.length && !session.team2.length) || !rooms) {
            return interaction.reply({ content: 'مافيه بيانات للافرقه او الرومات مو محفوظة', ephemeral: true });
        }

        await interaction.reply({ content: '⏳ قاعد انقلكم للرومات...' });

        for (const member of session.team1) {
            try { await member.voice.setChannel(rooms.team1); } catch (e) {}
        }
        for (const member of session.team2) {
            try { await member.voice.setChannel(rooms.team2); } catch (e) {}
        }
    }

    // زر الإرجاع للروم الأساسي
    if (interaction.customId === 'return_teams') {
        if (!session || !session.mainRoomId) {
            return interaction.reply({ content: 'مالقيت الروم الاساسي عشان ارجعكم له', ephemeral: true });
        }

        await interaction.reply({ content: '⏳ قاعد اسحبكم للروم الأساسي...' });

        const allParticipants = [...session.team1, ...session.team2];
        for (const member of allParticipants) {
            try { await member.voice.setChannel(session.mainRoomId); } catch (e) {}
        }
    }
});

// لا تنسَ تضع توكن البوت الجديد الخاص بك هنا
client.login('TOKEN');